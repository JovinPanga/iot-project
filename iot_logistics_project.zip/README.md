# IoT Logistics Analytics + Baseline Model + Cloud-Deployable Dashboard

This repo executes an end-to-end IoT-style data science workflow using the Kaggle dataset:
`muhammadahmaddaar/delivery-logistics-dataset-india-multi-partner`.

## What you get
- Ingestion via KaggleHub
- Cleaning + feature engineering
- EDA outputs (PNG)
- Baseline training (auto: classification if SLA/late exists, else regression via computed duration)
- Streamlit dashboard (KPIs, partner benchmarking, drill-down + single-row scoring)
- AWS EC2 deployment recipe

## Quickstart (Local)

### 1) Install
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Run pipeline (download → clean → train → EDA)
```bash
python -m src.pipeline --dataset muhammadahmaddaar/delivery-logistics-dataset-india-multi-partner --out .
```

Outputs:
- `data/raw.csv`
- `data/cleaned.csv`
- `models/model_pipeline.joblib`
- `reports/data_profile.json`
- `reports/eda_*.png`

### 3) Run dashboard
```bash
streamlit run app.py
```

## AWS EC2 (Free Tier)
1. Launch Ubuntu (t2.micro).
2. Security group: open inbound TCP 8501 (restrict to your IP).
3. On instance:
```bash
sudo apt update
sudo apt install -y python3-pip python3-venv
# upload this folder or git clone it
cd iot-logistics
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m src.pipeline --dataset muhammadahmaddaar/delivery-logistics-dataset-india-multi-partner --out .
streamlit run app.py --server.address 0.0.0.0 --server.port 8501
```

Optional systemd service: `reports/ec2_systemd.txt`.

## Target definition logic (documented in reports/data_profile.json)
- If an explicit SLA/late flag exists → classification target `is_late`
- Else, if pickup/delivery timestamps exist → regression target `delivery_duration_min`
- Else, fallback to most plausible timestamp pair by completeness
