import json
from pathlib import Path

import pandas as pd
import streamlit as st
import joblib
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "cleaned.csv"
MODEL_PATH = ROOT / "models" / "model_pipeline.joblib"
PROFILE_PATH = ROOT / "reports" / "data_profile.json"

st.set_page_config(page_title="IoT Logistics Dashboard", layout="wide")

@st.cache_data
def load_data():
    if DATA_PATH.exists():
        return pd.read_csv(DATA_PATH)
    return None

@st.cache_resource
def load_model():
    if MODEL_PATH.exists():
        return joblib.load(MODEL_PATH)
    return None

def load_profile():
    if PROFILE_PATH.exists():
        return json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    return {}

profile = load_profile()
df = load_data()
pipe = load_model()

st.title("IoT Logistics Analytics (Multi-Partner)")

if df is None:
    st.error("No cleaned dataset found. Run: python -m src.pipeline --dataset <kaggle-dataset-id> --out .")
    st.stop()

task = profile.get("task", "unknown")
target_col = profile.get("target_col", None)
partner_col = profile.get("partner_col", None)
location_col = profile.get("location_col", None)

with st.sidebar:
    st.header("Filters")
    if partner_col and partner_col in df.columns:
        partners = sorted(df[partner_col].astype(str).unique().tolist())
        sel_partner = st.multiselect("Partner", partners, default=partners[: min(len(partners), 5)])
    else:
        sel_partner = None

    if location_col and location_col in df.columns:
        locs = sorted(df[location_col].astype(str).unique().tolist())
        sel_loc = st.multiselect("Location", locs, default=locs[: min(len(locs), 5)])
    else:
        sel_loc = None

filtered = df.copy()
if sel_partner is not None and partner_col in filtered.columns:
    filtered = filtered[filtered[partner_col].astype(str).isin(sel_partner)]
if sel_loc is not None and location_col in filtered.columns:
    filtered = filtered[filtered[location_col].astype(str).isin(sel_loc)]

c1, c2, c3, c4 = st.columns(4)
c1.metric("Deliveries (filtered)", f"{len(filtered):,}")

if task == "classification" and target_col in filtered.columns:
    late_rate = float(filtered[target_col].mean())
    c2.metric("Late rate", f"{late_rate:.2%}")
    c3.metric("On-time rate", f"{(1-late_rate):.2%}")
else:
    if target_col in filtered.columns:
        c2.metric("Median duration (min)", f"{filtered[target_col].median():.1f}")
        c3.metric("P90 duration (min)", f"{filtered[target_col].quantile(0.90):.1f}")
        c4.metric("P95 duration (min)", f"{filtered[target_col].quantile(0.95):.1f}")

st.divider()

left, right = st.columns([1, 1])

with left:
    st.subheader("Target distribution")
    fig = plt.figure()
    if target_col and target_col in filtered.columns:
        if task == "classification":
            filtered[target_col].value_counts().plot(kind="bar")
            plt.xlabel("Class")
            plt.ylabel("Count")
        else:
            filtered[target_col].hist(bins=40)
            plt.xlabel("Minutes")
            plt.ylabel("Count")
    st.pyplot(fig, clear_figure=True)

with right:
    st.subheader("Partner KPI")
    if partner_col and partner_col in filtered.columns and target_col in filtered.columns:
        fig = plt.figure()
        if task == "classification":
            kpi = filtered.groupby(partner_col)[target_col].mean().sort_values(ascending=False).head(15)
            kpi.plot(kind="bar")
            plt.ylabel("Late rate")
        else:
            kpi = filtered.groupby(partner_col)[target_col].median().sort_values(ascending=False).head(15)
            kpi.plot(kind="bar")
            plt.ylabel("Median minutes")
        plt.tight_layout()
        st.pyplot(fig, clear_figure=True)
    else:
        st.info("Partner column not detected in dataset.")

st.divider()
st.subheader("Data preview")
st.dataframe(filtered.head(50), use_container_width=True)

st.divider()
st.subheader("Model scoring (single-row)")

if pipe is None:
    st.warning("No model found. Run training via pipeline first.")
else:
    idx = st.number_input("Row index (in filtered view)", min_value=0, max_value=max(len(filtered)-1, 0), value=0, step=1)
    row = filtered.iloc[[int(idx)]].copy()
    if target_col and target_col in row.columns:
        row_X = row.drop(columns=[target_col])
    else:
        row_X = row

    if task == "classification":
        proba = pipe.predict_proba(row_X)[:, 1][0]
        pred = int(proba >= 0.5)
        st.metric("Predicted late probability", f"{proba:.2%}")
        st.metric("Predicted class (late=1)", f"{pred}")
    else:
        pred = float(pipe.predict(row_X)[0])
        st.metric("Predicted duration (min)", f"{pred:.1f}")

st.divider()
with st.expander("Pipeline metadata / data card"):
    st.json(profile)
