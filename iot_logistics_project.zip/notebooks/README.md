This project is delivered as production-style scripts + dashboard.

If your course requires notebooks, create:
- 01_load_clean.ipynb: run the pipeline and inspect outputs
- 02_eda.ipynb: explore `data/cleaned.csv` and replicate plots
- 03_model.ipynb: test alternative models / feature sets
