import argparse
import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.metrics import mean_absolute_error, roc_auc_score, f1_score, classification_report
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier

from .utils import (
    normalize_columns, infer_timestamp_cols, parse_datetimes,
    pick_duration_pair, detect_label_column, detect_partner_column,
    detect_location_column, basic_profile
)

def download_dataset(dataset: str) -> Path:
    '''
    Downloads dataset via KaggleHub and returns local folder path.
    Requires Kaggle credentials configured (KAGGLE_USERNAME/KAGGLE_KEY or kaggle.json).
    '''
    import kagglehub
    path = kagglehub.dataset_download(dataset)
    return Path(path)

def find_main_table(folder: Path) -> Path:
    csvs = list(folder.rglob("*.csv"))
    if csvs:
        csvs.sort(key=lambda p: p.stat().st_size, reverse=True)
        return csvs[0]
    pars = list(folder.rglob("*.parquet"))
    if pars:
        pars.sort(key=lambda p: p.stat().st_size, reverse=True)
        return pars[0]
    raise FileNotFoundError("No .csv or .parquet found in downloaded dataset folder.")

def load_table(path: Path) -> pd.DataFrame:
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() == ".parquet":
        return pd.read_parquet(path)
    raise ValueError(f"Unsupported file type: {path}")

def clean_and_engineer(df: pd.DataFrame):
    df = normalize_columns(df)

    ts_cols = infer_timestamp_cols(df)
    df = parse_datetimes(df, ts_cols)

    missing_ratio = df.isna().mean()
    drop_cols = missing_ratio[missing_ratio > 0.60].index.tolist()
    df = df.drop(columns=drop_cols)

    start_col, end_col = pick_duration_pair(df)
    duration_col = None
    if start_col and end_col:
        duration_col = "delivery_duration_min"
        df[duration_col] = (df[end_col] - df[start_col]).dt.total_seconds() / 60.0
        df.loc[df[duration_col] <= 0, duration_col] = np.nan

        df["event_hour"] = df[start_col].dt.hour
        df["event_dow"] = df[start_col].dt.dayofweek
        df["event_month"] = df[start_col].dt.month

    label_col = detect_label_column(df)
    task = None
    target_col = None

    if label_col:
        s = df[label_col]
        if s.dtype == "bool":
            df["is_late"] = s.astype(int)
        else:
            if s.dtype == "object":
                s2 = s.astype(str).str.strip().str.lower()
                late = s2.isin(["late", "yes", "y", "true", "1", "breached", "sla breached"])
                ontime = s2.isin(["on time", "ontime", "no", "n", "false", "0", "met"])
                df["is_late"] = np.where(late, 1, np.where(ontime, 0, np.nan))
            else:
                df["is_late"] = (pd.to_numeric(s, errors="coerce") > 0).astype("float")
        target_col = "is_late"
        task = "classification"
        df = df.dropna(subset=[target_col])
    elif duration_col:
        target_col = duration_col
        task = "regression"
        df = df.dropna(subset=[target_col])
    else:
        numeric_candidates = [c for c in df.select_dtypes(include="number").columns if re.search(r"time|duration|minutes|mins|hrs|hours", c)]
        if numeric_candidates:
            target_col = numeric_candidates[0]
            task = "regression"
        else:
            raise RuntimeError("Cannot infer a target: no SLA/late label and no timestamp pair for duration.")

    partner_col = detect_partner_column(df)
    location_col = detect_location_column(df)

    num_cols = df.select_dtypes(include="number").columns
    cat_cols = df.select_dtypes(exclude="number").columns

    for c in num_cols:
        df[c] = df[c].fillna(df[c].median())
    for c in cat_cols:
        df[c] = df[c].fillna("unknown")

    meta = {
        "task": task,
        "target_col": target_col,
        "label_source_col": label_col,
        "duration_pair": {"start": start_col, "end": end_col},
        "partner_col": partner_col,
        "location_col": location_col,
        "timestamp_cols_parsed": ts_cols,
    }
    return df, meta

def train_model(df: pd.DataFrame, meta: dict):
    target_col = meta["target_col"]
    task = meta["task"]

    y = df[target_col]
    X = df.drop(columns=[target_col])

    num_cols = X.select_dtypes(include="number").columns
    cat_cols = X.select_dtypes(exclude="number").columns

    preprocess = ColumnTransformer(
        transformers=[
            ("num", "passthrough", num_cols),
            ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols),
        ]
    )

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    if task == "regression":
        model = RandomForestRegressor(n_estimators=300, random_state=42, n_jobs=-1)
        pipe = Pipeline([("prep", preprocess), ("model", model)])
        pipe.fit(X_train, y_train)
        preds = pipe.predict(X_test)
        metrics = {"mae": float(mean_absolute_error(y_test, preds))}
    else:
        model = RandomForestClassifier(n_estimators=400, random_state=42, n_jobs=-1)
        pipe = Pipeline([("prep", preprocess), ("model", model)])
        pipe.fit(X_train, y_train)
        proba = pipe.predict_proba(X_test)[:, 1]
        pred = (proba >= 0.5).astype(int)
        metrics = {
            "roc_auc": float(roc_auc_score(y_test, proba)),
            "f1": float(f1_score(y_test, pred)),
            "classification_report": classification_report(y_test, pred, output_dict=True),
        }

    return pipe, metrics

def save_eda(df: pd.DataFrame, meta: dict, out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    target = meta["target_col"]
    task = meta["task"]
    partner_col = meta.get("partner_col")

    plt.figure()
    if task == "regression":
        df[target].hist(bins=50)
        plt.title("Target distribution (duration minutes)")
        plt.xlabel("Minutes")
        plt.ylabel("Count")
    else:
        df[target].value_counts().plot(kind="bar")
        plt.title("Target distribution (is_late)")
        plt.xlabel("Class")
        plt.ylabel("Count")
    plt.tight_layout()
    plt.savefig(out_dir / "eda_target_distribution.png", dpi=160)
    plt.close()

    if partner_col and partner_col in df.columns:
        plt.figure()
        if task == "classification":
            kpi = df.groupby(partner_col)[target].mean().sort_values(ascending=False).head(15)
            kpi.plot(kind="bar")
            plt.title("Late rate by partner (top 15)")
            plt.ylabel("Late rate")
        else:
            kpi = df.groupby(partner_col)[target].median().sort_values(ascending=False).head(15)
            kpi.plot(kind="bar")
            plt.title("Median duration by partner (top 15)")
            plt.ylabel("Minutes")
        plt.tight_layout()
        plt.savefig(out_dir / "eda_partner_kpi.png", dpi=160)
        plt.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", required=True, help="Kaggle dataset id, e.g. owner/dataset-name")
    parser.add_argument("--out", default=".", help="Project root folder (default: current dir)")
    args = parser.parse_args()

    root = Path(args.out).resolve()
    data_dir = root / "data"
    models_dir = root / "models"
    reports_dir = root / "reports"
    data_dir.mkdir(exist_ok=True, parents=True)
    models_dir.mkdir(exist_ok=True, parents=True)
    reports_dir.mkdir(exist_ok=True, parents=True)

    folder = download_dataset(args.dataset)
    table_path = find_main_table(folder)
    raw = load_table(table_path)

    raw.to_csv(data_dir / "raw.csv", index=False)

    df, meta = clean_and_engineer(raw)
    df.to_csv(data_dir / "cleaned.csv", index=False)

    pipe, metrics = train_model(df, meta)
    joblib.dump(pipe, models_dir / "model_pipeline.joblib")

    profile = basic_profile(df)
    profile.update(meta)
    profile["metrics"] = metrics
    profile["source_table"] = str(table_path)
    profile["dataset"] = args.dataset

    (reports_dir / "data_profile.json").write_text(json.dumps(profile, indent=2), encoding="utf-8")

    save_eda(df, meta, reports_dir)

    print("Done.")
    print("Cleaned:", data_dir / "cleaned.csv")
    print("Model:", models_dir / "model_pipeline.joblib")
    print("Profile:", reports_dir / "data_profile.json")

if __name__ == "__main__":
    main()
