import re
import pandas as pd

def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [re.sub(r"\s+", "_", c.strip().lower()) for c in df.columns]
    return df

def find_col(df: pd.DataFrame, patterns):
    cols = list(df.columns)
    for p in patterns:
        rx = re.compile(p)
        for c in cols:
            if rx.search(c):
                return c
    return None

def infer_timestamp_cols(df: pd.DataFrame):
    patterns = [
        r"created", r"order", r"booking", r"pickup", r"dispatch",
        r"out_for_delivery", r"ofd", r"delivered", r"delivery",
        r"timestamp", r"date", r"time"
    ]
    ts_candidates = []
    for c in df.columns:
        if any(re.search(p, c) for p in patterns):
            ts_candidates.append(c)
    return ts_candidates

def parse_datetimes(df: pd.DataFrame, cols):
    df = df.copy()
    for c in cols:
        df[c] = pd.to_datetime(df[c], errors="coerce", utc=False, dayfirst=False)
    return df

def pick_duration_pair(df: pd.DataFrame):
    pickup = find_col(df, [r"pickup(_|)time", r"pickup(_|)date", r"picked", r"dispatch(_|)time"])
    delivered = find_col(df, [r"delivered(_|)time", r"delivered(_|)date", r"delivery(_|)time", r"drop(_|)time"])
    if pickup and delivered:
        return pickup, delivered

    ts_cols = infer_timestamp_cols(df)

    best = []
    for c in ts_cols:
        if pd.api.types.is_datetime64_any_dtype(df[c]):
            nn = df[c].notna().mean()
            best.append((nn, c))
    best.sort(reverse=True)

    if len(best) >= 2:
        c1, c2 = best[0][1], best[1][1]
        med1 = df[c1].dropna().median()
        med2 = df[c2].dropna().median()
        if pd.isna(med1) or pd.isna(med2):
            return c1, c2
        if med1 <= med2:
            return c1, c2
        return c2, c1

    return None, None

def detect_label_column(df: pd.DataFrame):
    return find_col(df, [
        r"sla(_|)breach", r"sla(_|)breached", r"late", r"delay", r"on(_|)time", r"breach"
    ])

def detect_partner_column(df: pd.DataFrame):
    return find_col(df, [r"partner", r"carrier", r"courier", r"fleet", r"vendor", r"service(_|)provider"])

def detect_location_column(df: pd.DataFrame):
    return find_col(df, [r"city", r"state", r"zone", r"region", r"hub", r"warehouse", r"pincode", r"pin(_|)code"])

def basic_profile(df: pd.DataFrame):
    return {
        "rows": int(df.shape[0]),
        "cols": int(df.shape[1]),
        "columns": list(df.columns),
        "missing_ratio_top10": df.isna().mean().sort_values(ascending=False).head(10).to_dict(),
        "numeric_cols": list(df.select_dtypes(include="number").columns),
        "categorical_cols": list(df.select_dtypes(exclude="number").columns),
    }
